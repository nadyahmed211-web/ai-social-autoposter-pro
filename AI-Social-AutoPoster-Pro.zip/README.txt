======================================================
AI SOCIAL AUTOPOSTER PRO - INSTALLATION & USER GUIDE
دليل التشغيل والاستخدام - أداة النشر الذكي وإدارة الحملات
======================================================

[AR] مرحباً بك في أداة AI Social AutoPoster Pro!
شكراً لثقتك واختيارك لمنتجات Ahmed Abu Omar الرقمية. هذه الأداة مصممة خصيصاً لمساعدتك على إدارة ونشر محتويدك على منصات التواصل الاجتماعي والمجموعات المستهدفة بأقصى سرعة وأمان تام.

طريقة الاستخدام:
1. فك ضغط ملف الـ ZIP.
2. افتح ملف `index.html` مباشرة بأي متصفح ويب (Google Chrome / Safari).
3. اكتب منشورك في الخانة المخصصة، وارفع صورة المنشور (اختياري).
4. اضغط على زر علامة (+) بجوار كل منصة لتسجيل وحفظ روابط صفحاتك (تُحفظ تلقائياً في متصفحك).
5. أضف روابط المجموعات المستهدفة في قسم استهداف المجموعات.
6. اضغط على زر "نشر ذكي ومتسلسل الآن" لتُنسخ الكلمات تلقائياً وتُفتح المنصات والجروبات بضغطة زر واحدة للصق والنشر!

الدعم الفني المباشر وتفعيل المنتجات:
- تواصل معنا عبر الواتساب للاستفسارات والدعم: https://wa.me/201206443652

---

[EN] Welcome to AI Social AutoPoster Pro!
Thank you for purchasing professional digital assets from Ahmed Abu Omar Studio. This tool is designed to streamline your social media posting and group campaign management efficiently and securely.

How to Use:
1. Extract the ZIP package.
2. Open `index.html` directly in any web browser.
3. Write your post content and optionally upload an image.
4. Click the (+) button next to each platform to save your profile/page links locally.
5. Add your targeted group links in the group manager section.
6. Click "Smart Auto-Dispatch" to copy your text to clipboard and instantly open all target platforms for quick pasting and posting!

Direct Support & Inquiries:
- Chat with us on WhatsApp: https://wa.me/201206443652

------------------------------------------------------
© Ahmed Abu Omar - Premium Digital Studio. All Rights Reserved.